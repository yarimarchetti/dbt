SELECT batchid FROM {{ source('test', 'vehicle')  }}
where batchid = 3669390000000000