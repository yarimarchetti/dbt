select vehicleid, count(1)
from {{ source('test', 'vehicle')  }}
group by vehicleid